//////////// SRH HOCHSCHULE HEIDELBERG ////////////
// Embedded Systems 
// Created by Cesar Inga 
// 14.06.2018 ////////////////////////////////////

#include "SpeedLevel.h"
#include "driverlib.h"

volatile unsigned int currentpwm;
volatile unsigned int runningIncreaseSpeed=0;
volatile unsigned int runningDecreaseSpeed=0;
volatile unsigned int newperiod = 1000;
const int speedvariation = 350;

void LCDshow (void);

Timer_A_initUpModeParam initUpParam_A1 =
{
    TIMER_A_CLOCKSOURCE_ACLK,               // ACLK Clock Source
    TIMER_A_CLOCKSOURCE_DIVIDER_1,          // ACLK/1 = 32768Hz
    0x2000,                                 // Timer period
    TIMER_A_TAIE_INTERRUPT_ENABLE ,         // Enable Timer interrupt
    TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE ,    // Enable CCR0 interrupt
    TIMER_A_DO_CLEAR,                       // Clear value
    false                                   // Not initialize here
};

Timer_A_initUpModeParam initUpParam_A2 =
{
    TIMER_A_CLOCKSOURCE_ACLK,               // ACLK Clock Source
    TIMER_A_CLOCKSOURCE_DIVIDER_1,          // ACLK/1 = 32768Hz
    0x9000,                                 // Timer period
    TIMER_A_TAIE_INTERRUPT_ENABLE ,         // Enable Timer interrupt
    TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE ,    // Enable CCR0 interrupt
    TIMER_A_DO_CLEAR,                       // Clear value
    false                                   // Not initialize here
};



IncreaseSpeed()
{
    if (runningIncreaseSpeed==1)
    {
        runningDecreaseSpeed=0;

                                newperiod = newperiod+speedvariation;


                                if (newperiod > PWM_PERIOD)
                                 {
                                    newperiod = 0;
                                 }

                                if (newperiod + speedvariation >= PWM_PERIOD)
                                                                                                {
                                                                                                Timer_A_initUpMode(TIMER_A1_BASE, &initUpParam_A1);
                                                                                                Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE);
                                                                                                }

                                 else
                                 {
                                   Timer_A_stop(TIMER_A1_BASE);
                                   GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );
                                   GPIO_setOutputLowOnPin( GPIO_PORT_P4, GPIO_PIN0 );
                                 }



                                currentpwm = newperiod; //This represents the new period set
                                TA0CCR1 = currentpwm-1; //The period in microseconds that the power is ON. It represent the duty cycle which is a percentage from TA0CCR0
                                LCDshow();

                               __bis_SR_register(LPM3_bits | GIE);                // re-enter LPM3.5
                               __no_operation();

    }
}

DecreaseSpeed()
{
    if (runningDecreaseSpeed==1)

    {
        runningIncreaseSpeed=0;
                                newperiod = newperiod-speedvariation;



                                if (newperiod <= 0)
                                        {
                                         newperiod = 0;
                                        }

                                if (newperiod - speedvariation <= 0)
                                                                                               {
                                                                                               Timer_A_initUpMode(TIMER_A1_BASE, &initUpParam_A2);
                                                                                               Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE);
                                                                                               }
                                 else
                                 {
                                   Timer_A_stop(TIMER_A1_BASE);
                                   GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );
                                   GPIO_setOutputLowOnPin( GPIO_PORT_P4, GPIO_PIN0 );
                                 }

                                currentpwm = newperiod; //This represents the new period set
                                TA0CCR1 = currentpwm-1; //The period in microseconds that the power is ON. It represent the duty cycle which is a percentage from TA0CCR0
                                LCDshow();

                                __bis_SR_register(LPM3_bits | GIE);         // re-enter LPM3.5
                                __no_operation();
    }

}

void PWM_Config(void)
{
               P1DIR |= BIT7;               //Set pin 1.7 to the output direction.
               P1SEL0 |= BIT7;              //Select pin 1.7 as our PWM output.
               TA0CCR0 = PWM_PERIOD-1;      //Set the period in the Timer A0 Capture/Compare 0 register to 1000 us.
               TA0CCR1 = PWM_PERIOD-1;      //The period in microseconds that the power is ON. It's the whole time, which translates to a 100% duty cycle.
               TA0CCTL1 = OUTMOD_7;         //Adjust the voltage when there is a variation
               TA0CTL = TASSEL_2 + MC_1;    //TASSEL_2 selects SMCLK as the clock source, and MC_1 tells it to count up to the value in TA0CCR0.

}
