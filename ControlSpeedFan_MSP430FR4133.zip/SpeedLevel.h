//////////// SRH HOCHSCHULE HEIDELBERG ////////////
// Embedded Systems 
// Created by Cesar Inga 
// 14.06.2018 ////////////////////////////////////

#ifndef SPEEDLEVEL_H_
#define SPEEDLEVEL_H_

#define PWM_PERIOD (2000)

extern volatile unsigned int currentpwm;
extern volatile unsigned int runningIncreaseSpeed;
extern volatile unsigned int runningDecreaseSpeed;
extern volatile unsigned int newperiod;
extern const int speedvariation;

#endif /* SPEEDLEVEL_H_ */
