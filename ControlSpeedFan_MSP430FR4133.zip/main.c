//////////// SRH HOCHSCHULE HEIDELBERG ////////////
// Embedded Systems 
// Created by Cesar Inga 
// 14.06.2018 ////////////////////////////////////

#include "driverlib.h"
#include "LCD.h"
#include "SpeedLevel.h"
#include <msp430fr4133.h>

void IncreaseSpeed (void);
void DecreaseSpeed (void);
void initGPIO (void);
void PWM_Config (void);

void main (void) {

    WDTCTL = WDTPW + WDTHOLD; // Stop watchdog timer

    initGPIO();               // Initializing and setting all outputs low to prevent floating input and reduce power consumption

    LCDf();                   // Initializing LCD function



   //displayScrollText("MANUAL FAN CONTROL SPEED IN RPM");
   //displayScrollText("S1 INCREASE");
   //displayScrollText("S2 DECREASE");

    //__bis_SR_register( GIE );
    __bis_SR_register( LPM3_bits | GIE );              // Enable interrupts globally
    //__no_operation();
}

#pragma vector=PORT1_VECTOR
__interrupt void pushbutton_ISR2 (void) {
    switch( __even_in_range( P1IV, P1IV_P1IFG7 )) {
    case P1IV_NONE:   break;// None
    case P1IV_P1IFG0:       // Pin 0
        __no_operation();
        break;
    case P1IV_P1IFG1:       // Pin 1
        __no_operation();
        break;
    case P1IV_P1IFG2:       // Pin 2 (button 1) Interruptor register IV

                // Calling PWM function
               PWM_Config();

               runningIncreaseSpeed=1;          // Calling the function to increase the speed

               IncreaseSpeed();

    case P1IV_P1IFG3:       // Pin 3
        __no_operation();
        break;
    case P1IV_P1IFG4:       // Pin 4
        __no_operation();
        break;
    case P1IV_P1IFG5:       // Pin 5
        __no_operation();
        break;
    case P1IV_P1IFG6:       // Pin 6
        __no_operation();
        break;
    case P1IV_P1IFG7:       // Pin 7
        __no_operation();
        break;
    default:   _never_executed();
    }
}

#pragma vector=PORT2_VECTOR
__interrupt void pushbutton_ISR (void) {
    switch( __even_in_range( P2IV, P2IV_P2IFG7 )) {
    case P2IV_NONE:   break;// None
    case P2IV_P2IFG0:       // Pin 0
        __no_operation();
        break;
    case P2IV_P2IFG1:       // Pin 1
        __no_operation();
        break;
    case P2IV_P2IFG2:       // Pin 2
        __no_operation();
        break;
    case P2IV_P2IFG3:       // Pin 3
        __no_operation();
        break;
    case P2IV_P2IFG4:       // Pin 4
        __no_operation();
        break;
    case P2IV_P2IFG5:       // Pin 5
        __no_operation();
        break;
    case P2IV_P2IFG6:       // Pin 6 (button 2) //Interruptor register IV

        // Calling PWM function
        PWM_Config();                    // Calling PWM function

        runningDecreaseSpeed=1;         // Calling the function to decrease the speed

        DecreaseSpeed();

    case P2IV_P2IFG7:       // Pin 7
        __no_operation();
        break;
    default:   _never_executed();
    }
}


#pragma vector=TIMER1_A0_VECTOR
__interrupt void CCR1_ISR (void)
{
    GPIO_toggleOutputOnPin( GPIO_PORT_P1, GPIO_PIN0 );  // Toggle LED1 (RED) LED on/off
}

#pragma vector=TIMER1_A1_VECTOR
__interrupt void timer1_ISR (void)
{
    switch( __even_in_range( TA1IV, TA1IV_TAIFG )) {
        case TA1IV_NONE: break;                 // (0x00) None
        case TA1IV_TACCR1:                      // (0x02) CCR1 IFG
            _no_operation();
            break;
        case TA1IV_TACCR2:                      // (0x04) CCR2 IFG
            _no_operation();
            break;
        case TA1IV_3: break;                    // (0x06) Reserved
        case TA1IV_4: break;                    // (0x08) Reserved
        case TA1IV_5: break;                    // (0x0A) Reserved
        case TA1IV_6: break;                    // (0x0C) Reserved
        case TA1IV_TAIFG:                       // (0x0E) TA1IFG - TAR overflow
            GPIO_toggleOutputOnPin( GPIO_PORT_P4, GPIO_PIN0 );  // Toggle LED2 (Green) LED on/off
            break;
        default: _never_executed();
    }
}

// Function InitGPIO(). Initializing GPIO

void initGPIO(void) {

    // Set all GPIO pins to output low to prevent floating input and reduce power consumption
       GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P4, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P6, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P7, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setOutputLowOnPin(GPIO_PORT_P8, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);

       GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P4, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P6, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P7, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
       GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);

       GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN1);

       // Configure button S1 (P1.2) interrupt
       GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN2, GPIO_HIGH_TO_LOW_TRANSITION);
       GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN2);
       GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN2);
       GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN2);

       // Configure button S2 (P2.6) interrupt
       GPIO_selectInterruptEdge(GPIO_PORT_P2, GPIO_PIN6, GPIO_HIGH_TO_LOW_TRANSITION);
       GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P2, GPIO_PIN6);
       GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN6);
       GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN6);

       // Set P4.1 and P4.2 as Secondary Module Function Input, LFXT.
       GPIO_setAsPeripheralModuleFunctionInputPin(
              GPIO_PORT_P4,
              GPIO_PIN1 + GPIO_PIN2,
              GPIO_PRIMARY_MODULE_FUNCTION
              );

       // Disable the GPIO power-on default high-impedance mode
       // to activate previously configured port settings
       PMM_unlockLPM5();
}
